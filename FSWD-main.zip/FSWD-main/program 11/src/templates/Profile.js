const Profile = () => {
    return <><h1>Welcome to Mrs. T.Jyotsna</h1><p>Assistant Professor, CSE Department, CMRIT</p></>
  };
  
  export default Profile;