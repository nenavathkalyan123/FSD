const ContactUs = () => {
    return <h1>CMRIT, Kandlakoya village, Medchal, Hyderabad</h1>;
  };
  
  export default ContactUs;